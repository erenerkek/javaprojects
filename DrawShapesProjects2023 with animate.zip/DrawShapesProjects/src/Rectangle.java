import java.awt.Graphics;

public class Rectangle extends Shape {

	@Override
	public void drawShape(Graphics g) {
		g.drawRect(getX(), getY(), getWidth(), getHeight());
	}

	@Override
	public void fillShape(Graphics g) {
		g.fillRect(getX(), getY(), getWidth(), getHeight());
		
	}

}
