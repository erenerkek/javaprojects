import java.awt.Graphics;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ShapeList {
	private ArrayList<Shape> list = new ArrayList<Shape>();
	
	public void add(Shape s) {
		list.add(s);
	}
	
	public void draw(Graphics g) {
		list.forEach(s -> s.fill(g));
		list.forEach(s -> s.draw(g));
		
	}
	
	public void move(int deltaX, int deltaY, int limitX, int limitY) {
		list.forEach(x -> x.move(deltaX, deltaY, limitX, limitY));
	}
	
	public void changeDirectionX() {
		list.forEach(x -> x.changeDirectionX());
	}
	
	public void changeDirectionY() {
		list.forEach(x -> x.changeDirectionY());
	}
	
	public void save(ObjectOutputStream out) throws IOException {
		out.writeObject(list);
	}

	public void load(ObjectInputStream in) throws ClassNotFoundException, IOException {
		list = (ArrayList<Shape>)in.readObject();
		
	}
	
	
}
