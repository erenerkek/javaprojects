import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JToolBar;

public class ShapeWindow extends JFrame {
	private Shape currentShape;
	private ShapeList list = new ShapeList();
	
	public ShapeWindow() {
		setTitle("Draw shapes application");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setSize(1000, 800);
		
		initToolbar();
		initMouseListeners();
	}
	
	
	

	private void initMouseListeners() {
		addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				if (currentShape != null) {
					list.add(currentShape);
					currentShape = null;
				}
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				if (currentShape != null) {
					currentShape.setX(e.getX());
					currentShape.setY(e.getY());
				}
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseMoved(MouseEvent e) {
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				if (currentShape != null) {
					currentShape.setWidth(e.getX() - currentShape.getX());
					currentShape.setHeight(e.getY() - currentShape.getY());
					
					repaint();
				}
			}
		});
		
	}




	private void initToolbar() {
		JToolBar toolbar = new JToolBar();
		
		JButton btn = new JButton("Add rectangle");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				currentShape = new Rectangle();
			}
		});
		
		toolbar.add(btn);
		
		btn = new JButton("Add elipse");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				currentShape = new Elipse();
			}
		});
		
		toolbar.add(btn);
		
		btn = new JButton("Change border color");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (currentShape != null)
					currentShape.setBorderColor(
							JColorChooser
							.showDialog(null, 
									"Dialog Title", 
									null));
			}
		});
		
		toolbar.add(btn);
		
		
		btn = new JButton("Change fill color");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (currentShape != null)
					currentShape.setFillColor(
							JColorChooser
							.showDialog(null, 
									"Dialog Title", 
									null));
			}
		});
		
		toolbar.add(btn);
		
		btn = new JButton("Save");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				save();
			}
		});
		
		toolbar.add(btn);
		
		btn = new JButton("Load");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				load();
			}
		});
		
		toolbar.add(btn);

		btn = new JButton("Move");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				list.move(50, 50, getSize().width, getSize().height);
				repaint();
			}
		});
		
		toolbar.add(btn);
		
		btn = new JButton("Change X direction");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				list.changeDirectionX();
				//list.move(20, 20);
				repaint();
			}
		});

		
		toolbar.add(btn);

		btn = new JButton("Animate");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Timer().schedule(new TimerTask() {
					
					@Override
					public void run() {
						list.move(20, 20, getSize().width, getSize().height);
						repaint();
					}
				}, 10, 500);
			}
		});

		
		toolbar.add(btn);


		
		add(toolbar, BorderLayout.PAGE_START);
		
	}
	
	public void load() {
		try {
			ObjectInputStream in = new ObjectInputStream(
					new FileInputStream("shapes.dat"));
			
			list.load(in);
			
			in.close();
			
			repaint();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void save() {
		try {
			ObjectOutputStream out = new ObjectOutputStream(
					new FileOutputStream("shapes.dat"));
			
			list.save(out);
			
			out.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
	public void paint(Graphics g) {
		super.paint(g);
		
		list.draw(g);
		
		if (currentShape != null) {
			currentShape.fill(g);
			currentShape.draw(g);
		}
		
		
	}


	public static void main(String[] args) {
		new ShapeWindow().setVisible(true);
	}

}
